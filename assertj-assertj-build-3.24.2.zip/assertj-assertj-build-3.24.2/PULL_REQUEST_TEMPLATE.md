#### Check List:
* Fixes #??? (ignore if not applicable)
* Unit tests : YES / NO / NA
* Javadoc with a code example (on API only) : YES / NO / NA
* PR meets the [contributing guidelines](https://github.com/assertj/assertj/blob/main/CONTRIBUTING.md)

Following the [contributing guidelines](https://github.com/assertj/assertj/blob/main/CONTRIBUTING.md) will make it easier for us to review and accept your PR.
